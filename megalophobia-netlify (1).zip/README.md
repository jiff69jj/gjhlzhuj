# Megalophobia

First-person scale city experience — walk among towers, drive a truck, claim a home, work at the MegaWorks factory.

**Made with Grok**

## Play

1. Open `megalophobia.html` in a modern browser (Chrome / Firefox / Edge), **or**
2. Host the folder on **GitHub Pages** / Netlify / any static host.

Keep the `sfx/` folder next to the HTML so sounds load.

## Controls

| Input | Action |
|--------|--------|
| WASD | Move |
| Mouse | Look |
| Space | Jump |
| Shift | Sprint |
| E | Enter/exit truck, claim/enter home, enter factory, do job |
| X | Abandon home (at your door) |
| F | Horn (while driving) |
| MMB (scroll-wheel click) | Phone |
| Esc | Release mouse |

## Features

- Scale city with Eiffel, Milad, Skytree, Burj
- Drivable truck (max 180 km/h)
- Money system ($100 start, +$50 per game day)
- Claimable homes + rent
- Enter apartment interior
- Day / night cycle
- **MegaWorks Factory** — huge interior, jobs:
  - Carry boxes — $18
  - Polish gears — $32
  - Clean floors — $12
- GTA-style phone (wallet, home, jobs, account)
- Sign up / log in (saved in this browser via `localStorage`)

## GitHub Pages

1. Create a new repo and upload:
   - `megalophobia.html`
   - `sfx/` (all mp3 files)
   - `index.html` (optional landing page)
   - this `README.md`
2. Settings → Pages → Deploy from branch `main` / root.
3. Open `https://<user>.github.io/<repo>/megalophobia.html`

## Note on accounts

Sign up / log in stores accounts **only in the visitor’s browser**. It does not sync across devices or users. For real online accounts you need a backend (Firebase, Supabase, etc.).

## License

Game code for personal / educational use. Audio files belong to their respective authors (see filenames).
